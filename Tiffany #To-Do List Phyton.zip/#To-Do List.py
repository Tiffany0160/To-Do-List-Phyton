import tkinter as tk
from tkinter import messagebox

def add_task():
    task = task_entry.get()
    if task:
        task_list.insert(tk.END, task)
        task_entry.delete(0, tk.END)
    else:
        messagebox.showwarning("Warning", "Task cannot be empty!")

def remove_task():
    try:
        selected_task = task_list.curselection()
        task_list.delete(selected_task)
    except:
        messagebox.showerror("Error", "No task selected!")

app = tk.Tk()
app.title("To-Do List")
app.geometry("400x300")
app.configure(bg="lightpink")  # Light pink background

# Task Entry
task_entry = tk.Entry(app, width=30, bg="lightyellow", fg="black")  # Yellow text box
task_entry.pack(pady=10)

# Add Button
add_button = tk.Button(app, text="Add Task", command=add_task, bg="blue", fg="white")  # Blue button
add_button.pack(pady=5)

# Remove Button
remove_button = tk.Button(app, text="Remove Task", command=remove_task, bg="red", fg="white")  # Red button
remove_button.pack(pady=5)

# Task List
task_list = tk.Listbox(app, width=40, height=10, bg="white", fg="black")
task_list.pack(pady=10)

app.mainloop()
